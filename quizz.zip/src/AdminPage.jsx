import Create from "./Create"
import DeleteQ from "./DeleteQ"
export default function Admin(){
return(
<>
<h1>ADMIN PAGE</h1>
<Create/>
<DeleteQ/>
</>
)
}