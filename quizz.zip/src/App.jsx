import "./App.css";
import QuizzPage from "./QuizPage";

function App() {
  /* function renderPart() {
    if (showResult) {
      return <Result />;
    } else if (quizzStated) {
      return <Quizz />;
    } else {
      return <button>Stata quizz</button>;
    }
  } */

  return <div>
    
  </div>;
}

export default App;
